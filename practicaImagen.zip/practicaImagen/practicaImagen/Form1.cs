using practicaImagen.Properties;

namespace practicaImagen
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = Properties.Resources._is;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = Properties.Resources._06;
        }



        private void button3_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = Properties.Resources.s;
        }
    }
}